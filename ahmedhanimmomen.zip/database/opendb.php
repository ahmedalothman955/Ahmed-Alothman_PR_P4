<?php
$dbaselink=mysqli_connect($dbhost,$dbuser,$dbpass,$dbname) 
or die(" you can not connecting".
mysqli_connect_erorr());
set_time_limit(60);
?>