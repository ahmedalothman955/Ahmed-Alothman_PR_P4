function red() {
  document.body.style.background = "#ff4d4d";
  document.body.style.marginRight=0;
 
}
function green() {
    document.body.style.background = "#4dff4d";
   
}

